from DBProcessor import DBProcessor

debugDP = True

class InventoryProcessor(DBProcessor):

    def build_ins_code(self, inventory_id: int, inventory_date: str):
        DBProcessor.check_for_date(inventory_date)
        sql = str.format("INSERT INTO Inventories (InventoryID, InventoryDate) "
                         "VALUES ({id},'{date}');", id=inventory_id, date=inventory_date)
        return sql

    def build_upd_code(self, inventory_id: int, inventory_date: str ):
        DBProcessor.check_for_date(inventory_date)
        sql = str.format("UPDATE Inventories SET InventoryDate = '{date}' "
                         "WHERE InventoryID = {id};", id=inventory_id, date=inventory_date)
        return sql

    def build_del_code(self, inventory_id: int):
        sql = str.format("DELETE FROM Inventories "
                         "WHERE InventoryID = {id};", id=inventory_id)
        return sql

    def build_sel_code(self, inventory_id: int = None):
        if inventory_id is not None:
            w = ' WHERE InventoryID = ' + str(inventory_id)
        else:
            w = ''
        sql = str.format("SELECT InventoryID, InventoryDate "
                         "FROM Inventories{WHERE};", WHERE=w)
        return sql


# Test InventoryProcessor
if debugDP == True:
    ip = InventoryProcessor(':memory:')
    print(ip.build_ins_code(inventory_id=1, inventory_date='2000-01-01'))
    print(ip.build_upd_code(inventory_id=1, inventory_date='2000-02-02'))
    print(ip.build_del_code(inventory_id=1))
    print(ip.build_sel_code())

    # Create a table for testing
    crs = ip.db_con.cursor()
    crs.execute("CREATE TABLE Inventories (InventoryID int, InventoryDate date);")
    ip.db_con.commit()
    for row in crs.execute("Select name, sql From sqlite_master Where type='table;'"):
        print(row)
    ip.db_con.commit()

    # Test SQL Transactions
    ip.execute_sql_code(ip.build_ins_code(inventory_id=1, inventory_date='2000-01-01')).close()
    for row in ip.execute_sql_code(ip.build_sel_code()):
        print(row)

    ip.execute_sql_code(ip.build_upd_code(inventory_id=1, inventory_date='2000-02-02')).close()
    for row in ip.execute_sql_code(ip.build_sel_code(inventory_id=1)):
        print(row)

    ip.execute_sql_code(ip.build_del_code(inventory_id=1)).close()
    for row in ip.execute_sql_code(ip.build_sel_code()):
        print(row)